<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ordenar Números</title>
</head>
<body>
    <?php 
    require_once("encabezado.php");
    ?>
    <br>

    <h1 style="color: black;  text-align: center;">Ordenar Números de Mayor a Menor</h1>
    
    <form action="ordenar.php" method="post" style="text-align:center; border:5px solid black; color:black; background-color:rgba(116, 34, 137, 0.552); width:45%; margin-left:29%; font-size: 73%; margin-top: 4%;">
        <label for="num1">Número 1:</label>
        <input type="number" name="num1" min="0" required>
        <br><br>

        <label for="num2">Número 2:</label>
        <input type="number" name="num2" min="0" required>
        <br><br>

        <label for="num3">Número 3:</label>
        <input type="number" name="num3" min="0" required>
        <br><br>

        <label for="num4">Número 4:</label>
        <input type="number" name="num4" min="0" required>
        <br><br>

        <input type="submit" name="ordenar" value="Ordenar">
    </form>

    <?php 
    require_once("pieDePagina.php");
    ?>
</body>
</html>

