<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar Números</title>
</head>
<body>
    <?php 
    require_once("encabezado.php");
    ?>

    <h1 style="color:black; font-size:50px;margin-left:28%;">Números en un Rango</h1>

    <?php
    if (isset($_POST['mostrar'])) {
        $numero1 = $_POST['numero1'];
        $numero2 = $_POST['numero2'];

        echo  "<FONT COLOR='black'><center>"."<h2>Números desde $numero1 hasta $numero2:</h2>";
        echo "<ul>";

        for ($i = $numero1; $i <= $numero2; $i++) {
            echo  "<FONT COLOR='black'><center>"."<li>$i</li>";
        }

        echo "</ul>";
    }
    ?>
    <br>
    <br>
    <a href="contarde _de_hasta.php"> volver
    <br>
</body>
<br><br>


    <?php 
    require_once("pieDePagina.php");
    ?>
</body>
</html>
