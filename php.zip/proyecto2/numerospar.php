<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar Números Pares</title>
</head>
<body>
    <?php 
    require_once("encabezado.php");
    ?>

    <h1 style="color: black;  text-align: center;">Números Pares en un Rango</h1>

    <?php
    if (isset($_POST['mostrarPares'])) {
        $numero1 = $_POST['numero1'];
        $numero2 = $_POST['numero2'];

        echo "<FONT COLOR='black'><center>". "<h2>Números Pares desde $numero1 hasta $numero2:</h2>";
        echo "<FONT COLOR='black'><center>"."<ul>";

        for ($i = $numero1; $i <= $numero2; $i++) {
            if ($i % 2 == 0) {
                echo "<li>$i</li>";
            }
        }

        echo "<FONT COLOR='black'><center>". "</ul>";
    }
    ?>
    <br>
    <br>
    <a href="pares.php"> volver
    <br>
    <br>
 
    <?php 
    require_once("pieDePagina.php");
    ?>
</body>
</html>
