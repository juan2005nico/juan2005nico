<!DOCTYPE html>
<html>
    <head>
          <!-- definimos la tabla de caracteres UTF-8 para admitir tildes y eñes -->
          <meta naame="tipo-contenido" content="text/html;" http-equiv="content-type" charset="utf-8">
          <!-- definimos datos de AUTOR DE PÁGINA, DESCRIPCIÓN, PALABRAS CLAVE (Para Buscadores) y TÍTULO DE LA PÁGINA --><!-- REEMPLACE O AJUSTE ESTAS LÍNEAS SEGUN LOS DATOS Y CONTENIDOS DE SU PÁGINA WEB -->
          <meta name="descripciòn" content="Pagina WEB de la empresa de consultoria y desarrollo de software">
          <meta name="author" content ="Sara Vanessa Vasallo Suarez">
          <meta name="keywords" content="Asesoria informatica, hardware, software, diseño web">
          <title>Analisis y desarrollo de algoritmos</title>
          <link rel="stylesheet" type="text/css" href="css\style.css">
          <style type="text/css"></style> 
    </head>
    <body>
        <table style="text-align: left; width: 100%;" border="0" cellpadding="2" cellspacing="2">

            <tbody>
              <tr >
                <td style="vertical-align: top; width:299px;"><img   style="width:360px; height: 246px; border-radius: 40%; margin-top: 23%;margin-left: 23%;" alt="logo" src="imagenes\logo.png"></td>
                <td style="vertical-align: middle; width: 680px;"><big style="color: rgb(46, 5, 118);margin-left:36%;"><big><big><big><big>AT ADSO UCS<br>
                <small><small style="margin-left: 28%;">Asesorías Técnicas en ADSO UCS</small></small></big></big></big></big></big><br>
                <span  style="color: rgb(67, 13, 54); font-family: Arial,Tahoma,Helvetica,FreeSans,sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; background-color: transparent; display: inline ! important; float: none;margin-left: 22%;">
                  <br><h5 style="margin-left:19%;">Empresa especializada en Asesorías y soporte en Desarrollo de sofware.</h5> </span><br>
                </td>
              </tr>
            </tbody>
            <form>
                <th>
                  
                    <h1 style="color:#800080; margin-top: 29%;">Consultar</h1>
                    <h3 style="color: black;">CONVERSIÒN DE SISTEMAS NÙMERICOS </h3> 
                    <br>
                    <a href="index1.php" style="color:#F0FFFF; border-radius: 2%; width:30px; font-family: Arial, Helvetica, sans-serif; font-weight: 400;border-radius: 10px; margin:10px 110px; padding:15px 20px; background-color: rgb(194, 149, 236);">INGRESAR</a>
                    
                </th>
            </form>
                
          
            
    </body>
</html>