<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="ressultado" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="css\style.css">
</head>
<?php 
    // ---- cargamos plantilla para mostrar la cabecera
    require_once("encabezado.php");

    //----  aquí proyectamos el diseño del menú principal


?>
<body>
    <h1 style="color: black; text-align: center;">mostrar el resultado</h1>
    <br>
    <?php
    $post = (isset($_POST['base']) && !empty($_POST['base'])) && (isset($_POST['altura'])&&!empty($_POST['altura']) );
    if($post){
        $base=htmlspecialchars($_POST['base']);
        $altura=htmlspecialchars($_POST['altura']);
        //fesultado 
        echo "<FONT COLOR='black'><center>". "<FONT COLOR='black'><center>"."El area del triangulo es: ";
        echo "<FONT COLOR='black'><center>".round(($_POST['base'] * $_POST['altura']) /2, $precision =2),"cm<sup>2</sup>";
    }else{
        echo "<FONT COLOR='black'><center>"."Faltan datos verificar porfavor....";
    }
    ?>
    <br>
    <br>
    <a href="area-triangulo.php"> volver
    <br>
</body>
<br><br>

<?php 
    // ---- cargamos plantilla para mostrar la cabecera
    require_once("pieDePagina.php");

    //----  aquí proyectamos el diseño del menú principal



?>
</html>
</html>