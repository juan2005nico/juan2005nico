<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="ressultado" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="css\style.css">
</head>
<?php 
    // ---- cargamos plantilla para mostrar la cabecera
    require_once("encabezado.php");

    //----  aquí proyectamos el diseño del menú principal


?>
<body>
 <br>
 
    <h1 style="color: black; text-align: center;">mostrar el resultado</h1>
    <br>
    <?php

    
    $post = (isset($_POST['radio']) && !empty($_POST['radio']));
    if($post){
        $radio=htmlspecialchars($_POST['radio']);
        $ra=$radio*$radio;


        //fesultado 
        echo "<FONT COLOR='black'><center>" .  "El area de la circuferencia  es: ";
        echo "<FONT COLOR='black'><center>".round(($area= $ra*3.1416), $precision =2),"cm<sup>2</sup>";
    }else{
        echo "Faltan datos verificar porfavor....";
    }
    ?>
    <br>
    <br>
    <a href="areade-circuferencia.php"> volver
    <br>
    <br>

</body>
<br><br>

    <?php 
    // ---- cargamos plantilla para mostrar la cabecera
    require_once("pieDePagina.php");

    //----  aquí proyectamos el diseño del menú principal

?>

</html>