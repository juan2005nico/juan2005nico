<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Multiplicar</title>
</head>
<body>
    <?php 
    require_once("encabezado.php");
    ?>

    <h1 style="color: black;  text-align: center;">Generar Tabla de Multiplicar</h1>
    
    <form action="taba_de_multplicar.php" method="post" style="text-align:center; border:5px solid black; color:black; background-color:rgba(116, 34, 137, 0.552); width:45%; margin-left:29%; font-size: 73%; margin-top: 4%;">
        <label for="numero">Número:</label>
        <input type="number" name="numero" min="1" required>
        <br><br>

        <label for="limite">Límite:</label>
        <input type="number" name="limite" min="1" required>
        <br><br>

        <input type="submit" name="generar" value="Generar">
    </form>
    <br>
    <br>
    <a href="index1.php"> volver
    <br>
    <br>

    <?php 
    require_once("pieDePagina.php");
    ?>
</body>
</html>



