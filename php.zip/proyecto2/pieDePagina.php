<?php
?>
<br>
    <footer class="footer">
		<div class="contenedor contenedor-footer">
			<div class="footer-text">
				<p>&copy; A D S O - 20693143 | Todos los derechos reservados | 2023 </p>
			</div>
		</div>
	</footer>
