<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado de la División</title>
</head>
<body>
    <?php 
    require_once("encabezado.php");
    ?>
<br>
    <h1 style="color:black; font-size:50px;margin-left:28%;">Resultado de la División</h1>

    <?php
    if (isset($_POST['calcular'])) {
        $dividendo = $_POST['dividendo'];
        $divisor = $_POST['divisor'];

        if ($divisor != 0) {
            $resultado = $dividendo / $divisor;
            echo "<FONT COLOR='black'><center>"."<p>$dividendo ÷ $divisor = $resultado</p>";
        } else {
            echo "<FONT COLOR='black'><center>". "<p>No es posible dividir por cero.</p>";
        }
    }
    ?>

   <br>
    <br>
    <a href="calculardivisión.php"> volver
    <br>
    <br>

    <?php 
    require_once("pieDePagina.php");
    ?>
</body>
</html>

    


