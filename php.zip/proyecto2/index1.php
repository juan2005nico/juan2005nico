<!DOCTYPE html>
<html>
    <head>
        <!-- definimos la tabla de caracteres UTF-8 para admitir tildes y eñes -->
        <meta naame="tipo-contenido" content="text/html;" http-equiv="content-type" charset="utf-8">
        <!-- definimos datos de AUTOR DE PÁGINA, DESCRIPCIÓN, PALABRAS CLAVE (Para Buscadores) y TÍTULO DE LA PÁGINA --><!-- REEMPLACE O AJUSTE ESTAS LÍNEAS SEGUN LOS DATOS Y CONTENIDOS DE SU PÁGINA WEB -->
       <meta name="descripciòn" content="Pagina WEB de la empresa de consultoria y desarrollo de software">
       <meta name="author" content ="Sara Vanessa Vasallo Suarez">
       <meta name="keywords" content="Asesoria informatica, hardware, software, diseño web">
       <title>Analisis y desarrollo de algoritmos</title>
       <link rel="stylesheet" type="text/css" href="css\style.css">
       <style type="text/css"></style> 
    </head>
    
    <body>
        <div class="ss">
           <br>
           <h1>EJERCICIOS DE ALGORITMOS</h1>
           <br>
           <td>PRESENTADO POR: Vanessa Vasallo Suárez <br> Juan David Valdez Cruz <br>Nicol Portilla</td>
           <br><br> 
           <td>CURSO:  2693143 ADSO</td>
           <br><br>
           <td> SENA-CDAE Villeta </td>
           <br>
           
        </div>
        <article class="nn">
            <div class="sn">
                <ul>
                   <br>
                   <h2 style="text-align: left; margin-left: 24px;margin-top:12px;">EXTRUCTURAS SECUENCIALES:</h2>
                   <a style="text-align:center; font-size: 26px;" href="area-triangulo.php">Area de un triangulo</a><br>
                   <a style="text-align:center; font-size: 26px;" href="volumen-cilindro.php">Volumen de un cilindro</a><br>
                   <a style="text-align:center; font-size: 26px;" href="areade-circuferencia.php">Valores de una circuferencia</a><br>
                </ul>
            </div>
            <br><br>
            <br><br>
            
            <div class="sn1">
                
                 <ul>
                    <h2 style="text-align: left; margin-left: 24px;margin-top:12px;">EXTRUCTURAS CONDICIONALES:</h2>
                    <a style="text-align:center; font-size: 26px;" href="ordenar-4-numeros.php">analisis de un valor de 4 numeros</a><br>
                    <a style="text-align:center; font-size: 26px;" href="calculardivisión.php">Divición</a>
                </ul>
            </div>
            <br>
            <div class="sn2">
                <ul>
                   <h2 style="text-align: left; margin-left: 24px;margin-top:12px;">EXTRUCTURAS REPETITIVA:</h2>
                   <a style="text-align: center;  font-size: 26px;" href="tablademultiplicar.php">Tabla de multiplicar</a><br>
                   <a style="text-align: center;  font-size: 26px;" href="contarde _de_hasta.php">Rangos de números</a><br>
                   <a style="text-align: center;  font-size: 26px;" href="pares.php">Números pares</a><br>
               </ul>
           </div>
      <br>
  </article>
        
    </body>
    <br>
    <br>


</html>