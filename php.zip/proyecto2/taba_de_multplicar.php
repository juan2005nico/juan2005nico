<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Multiplicar</title>
</head>
<body>
    <?php 
    require_once("encabezado.php");
    ?>

    <h1 style="color:black; font-size:50px;margin-left:15%;">Tabla de Multiplicar</h1>

    <?php
    if (isset($_POST['generar'])) {
        $numero = $_POST['numero'];
        $limite = $_POST['limite'];

        echo "<FONT COLOR='black'><center>"."<h2>Tabla de multiplicar del $numero hasta el $limite</h2>";
        echo "<FONT COLOR='black'><center>"."<ul>";

        for ($i = 1; $i <= $limite; $i++) {
            $resultado = $numero * $i;
            echo "<FONT COLOR='black'><center>"."<li>$numero x $i = $resultado</li>";
        }

        echo "<FONT COLOR='black'><center>"."</ul>";
    }
    ?>
  <br>
    <br>
    <a href="tablademultiplicar.php"> volver
    <br>
    <br>


    <?php 
    require_once("pieDePagina.php");
    ?>
</body>
</html>
