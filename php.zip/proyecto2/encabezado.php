<?php
?>
     <link rel="stylesheet" type="text/css" href="css\style.css">
    <header>
        
        <div class="marco">
          <video class="video" src="imagenes\video1.mp4" controls width="250px" height="250" autoplay></video>
           <h1 class="t">
               <br>
               Taller repaso estructura de programación
               <br>
           </h1>
           <div class="texto">
           <br>
          
           <h2 class="tt">Integrantes:</h2>
         
           <h3 class="ttt">Vanessa vasallo <br> Juan David Valdez Cruz <br>Nicol Portilla </h3>
           <br>
           </div>
        </div>
    </header>