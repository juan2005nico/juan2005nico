<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar Números Pares</title>
</head>
<body>
    <?php 
    require_once("encabezado.php");
    ?>

    <h1 style="color: black; text-align: center;">Mostrar Números Pares en un Rango</h1>
    
    <form action="numerospar.php" method="post" style="text-align:center; border:5px solid black; color:black; background-color:rgba(116, 34, 137, 0.552); width:45%; margin-left:29%; font-size: 73%; margin-top: 4%;">
        <label for="numero1">Número Inicial:</label>
        <input type="number" name="numero1" min="1" required>
        <br><br>

        <label for="numero2">Número Final:</label>
        <input type="number" name="numero2" min="1" required>
        <br><br>

        <input type="submit" name="mostrarPares" value="Mostrar Pares">
    </form>
    <br>
    <br>
    <a href="index1.php"> volver
    <br>
    <br>

    <?php 
    require_once("pieDePagina.php");
    ?>
</body>
</html>

