<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Números Ordenados</title>
</head>
<body>
    <?php 
    require_once("encabezado.php");
    ?>

    <h1 style="color:black; font-size:50px;margin-left:15%;">Ordenar Dos Números</h1>
    
    <form action="ordenar_dos-numeros.php" method="post" style="text-align:center; border:5px solid black; color:black; background-color:rgba(116, 34, 137, 0.552); width:45%; margin-left:29%; font-size: 73%; margin-top: 4%;">
        <label for="num1">Número 1:</label>
        <input type="number" name="num1" min="0" required>
        <br><br>

        <label for="num2">Número 2:</label>
        <input type="number" name="num2" min="0" required>
        <br><br>

        <input type="submit" name="ordenar" value="Ordenar">
    </form>
    <br>
    <br>
    <a href="tablademultiplicar.php"> volver
    <br>
    <br>
<br><br>
    <?php 
    require_once("pieDePagina.php");
    ?>
</body>
</html>


