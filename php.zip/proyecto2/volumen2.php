<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="ressultado" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="css\style.css">
</head>
<?php 
    // ---- cargamos plantilla para mostrar la cabecera
    require_once("encabezado.php");

    //----  aquí proyectamos el diseño del menú principal

?>
<body >
    <br>
    <br>
    <h1 style="color: black; text-align: center;">VOLUMEN DEL CILINDRO</h1>
<?php //Ejemplo aprenderaprogramar.com

$post = (isset($_POST['diam']) && !empty($_POST['diam']))&& (isset($_POST['altu'])&&!empty($_POST['altu']) );
if($post){
 $diametro = $_POST['diam'];
 $altura = $_POST['altu'];
 $radio = $diametro/2;
 $Pi = 3.141593;
 $volumen = $Pi*$radio*$radio*$altura;
 echo "<center>";
echo "<FONT COLOR='black'><center>"."<br/> &nbsp; El volumen del cilindro es de:  <br>". $volumen. "metros cúbicos ";
echo "<FONT COLOR='black'><center>"."<center></table>";
}
?>

<br>
    <br>
    <a href="volumen-cilindro.php"> volver
    <br>
    <br>
<br>

</body>

<?php 
    // ---- cargamos plantilla para mostrar la cabecera
    require_once("pieDePagina.php");

    //----  aquí proyectamos el diseño del menú principal

?>

</html>