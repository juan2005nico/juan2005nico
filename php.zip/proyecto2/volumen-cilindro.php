<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>triangulo</title>
    <link rel="stylesheet" type="text/css" href="css\style.css">

</head>
    <?php 
    // ---- cargamos plantilla para mostrar la cabecera
    require_once("encabezado.php");

    //----  aquí proyectamos el diseño del menú principal


?>
<br>
<br>
<body>
    
<form action="volumen2.php" method="post" style="text-align:center;border:10%; border:5%;border-color: black;color:black; background-color:rgba(116, 34, 137, 0.552); width:45%; margin-left:29%;font-size: 73%;" >
<br>
<br>
 <p> CÁLCULO DEL VOLUMEN DE UN CILINDRO </p>
 <br/>
 <br/>
 Introduzca el diámetro en metros: <input type="text" name="diam" value="">
 <br/> 
 <br/>
 Introduzca la altura en metros: <input type="text" name="altu" value="">
 <br/> 
 <br/>
 <input value="Calcular" type="submit" />
 </form> 
 <br>
 <br>

 <br>
    <br>
    <a href="index1.php"> volver
    <br>
    <br>
<br>

</body>
<br>
<br>
<?php 
    // ---- cargamos plantilla para mostrar la cabecera
    require_once("pieDePagina.php");

    //----  aquí proyectamos el diseño del menú principal



?>
</html>