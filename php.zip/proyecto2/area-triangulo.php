<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>triangulo</title>
    <link rel="stylesheet" type="text/css" href="css\style.css">

</head>
<?php 
    // ---- cargamos plantilla para mostrar la cabecera
    require_once("encabezado.php");

    //----  aquí proyectamos el diseño del menú principal


?>
<body>
    <br><br>

    <h2 style="color: black;  text-align: center;">Calcular el area de un Triangulo</h2>
   <form action="area1-triangulo.php" method="post" style="text-align:center;border:10%; border:5%;border-color: black;color:black; background-color:rgba(116, 34, 137, 0.552); width:45%; margin-left:29%;margin-top: 4%;"> 
     <h5>Ingresa la base del Triangulo <input type="number" name="base" min="0" autofocus=""></h5>
     <br>
     <br>
     <h5>Ingresa la altura del Triangulo <input type="number" name="altura" min="0"></h5>
     <br>
     <br>
     <input type="submit" name="aceptar">
   </form>
<br>
    <br>
    <a href="index1.php"> volver
    <br>
    <br>
<br><br>
</body>


    <?php 
    // ---- cargamos plantilla para mostrar la cabecera
    require_once("pieDePagina.php");

    //----  aquí proyectamos el diseño del menú principal

?>
<br>
</html>







