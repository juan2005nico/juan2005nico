<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de Divisiones</title>
</head>
<body>
    <?php 
    require_once("encabezado.php");
    ?>
    <br>

    <h1 style="color:black; font-size:50px;margin-left:28%;">Calculadora de Divisiones</h1>
    
    <form action="división.php" method="post" style="text-align:center; border:5px solid black; color:black; background-color:rgba(116, 34, 137, 0.552); width:45%; margin-left:29%; font-size: 73%; margin-top: 4%;">
        <label for="dividendo">Dividendo:</label>
        <input type="number" name="dividendo" min="1" required>
        <br><br>

        <label for="divisor">Divisor:</label>
        <input type="number" name="divisor" min="1" required>
        <br><br>

        <input type="submit" name="calcular" value="Calcular">
    </form>
    <br>
    <br>
    <a href="index1.php"> volver
    <br>
    <br>
</body>
<br><br>


    <?php 
    require_once("pieDePagina.php");
    ?>
</body>
</html>


