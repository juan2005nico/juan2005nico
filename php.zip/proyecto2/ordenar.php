<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Números Ordenados</title>
</head>
<body>
    <?php 
    require_once("encabezado.php");
    ?>
    <br>

    <h1 style="color: black; text-align: center;">Números Ordenados de Mayor a Menor</h1>
    <br>
    <?php
    if (isset($_POST['ordenar'])) {
        $num1 = $_POST['num1'];
        $num2 = $_POST['num2'];
        $num3 = $_POST['num3'];
        $num4 = $_POST['num4'];

        // Almacenar los números en un array
        $numeros = [$num1, $num2, $num3, $num4];

        // Ordenar los números de mayor a menor
        rsort($numeros);

        // Mostrar los números ordenados
        echo "<FONT COLOR='black'><center>"."<p>Números Ordenados: " . implode(", ", $numeros) . "</p>";
    }
    ?>

    <?php 
    require_once("pieDePagina.php");
    ?>
</body>
</html>
